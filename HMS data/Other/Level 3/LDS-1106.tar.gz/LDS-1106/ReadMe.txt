################################################################
Dataset Information
################################################################

Dataset Name:
Metrics other than potency reveal systematic variation in responses to cancer drugs

Dataset Description:
The following is the abstract from Fallahi-Sichani et al. (2013) Nature Chemical Biology: <i>Large-scale analysis of cellular response to anticancer drugs typically focuses on variation in potency (half-maximum inhibitory concentration, (IC50)), assuming that it is the most important difference between effective and ineffective drugs or sensitive and resistant cells. We took a multiparametric approach involving analysis of the slope of the dose-response curve, the area under the curve and the maximum effect (Emax). We found that some of these parameters vary systematically with cell line and others with drug class. For cell-cycle inhibitors, Emax often but not always correlated with cell proliferation rate. For drugs targeting the Akt/PI3K/mTOR pathway, dose-response curves were unusually shallow. Classical pharmacology has no ready explanation for this phenomenon, but single-cell analysis showed that it correlated with significant and heritable cell-to-cell variability in the extent of target inhibition. We conclude that parameters other than potency should be considered in the comparative analysis of drug response, particularly at clinically relevant concentrations near and above the IC50.</i)

--Files in Package:
20120.txt
Cell_Line_Metadata.txt
MetadataPropertyMapping.txt
ReadMe.txt
Small_Molecule_Metadata.txt

################################################################
Center-specific Information
################################################################

Center-specific Name:
HMS_LINCS

Center-specific Dataset ID:
20120

Center-specific Dataset Link:
http://lincs.hms.harvard.edu/db/datasets/20120/

################################################################
Assay Information
################################################################

Assay Protocol:
The methods are fully described in Fallahi-Sichani et al. (2013) Nature Chemical Biology. Note that the primary data analyzed by Fallahi-Sichani et al. were obtained experimentally by the laboratory of Dr. Joe Gray (Oregon Health Sciences University) and are reported in Heiser et al. (2012) PNAS; PMID: 22003129.<br />
<br />
<b>"NaN" or "No Response" data in the results refer to one of these situations:</b>
1- Dose-response for that specific cell line/compound combination has not been measured.
2- Dose-response for that specific cell line/compound combination shows higher statistical quality (based on extra-sum-of-squares F test) when fitted to a constant model (y = E_inf) in comparison with the sigmoidal model.
3- Dose-response for that specific cell line/compound combination shows Hill slope < 0.25.
4- Dose-response for that specific cell line/compound combination has R^2 < 0.70.<br />
Based on definition, situations 2 & 3 are associated with resistance of the cell line to the measured drugs. Situation 4 is associated with huge experimental noise which, to our experience, arises mostly again due to resistance. We think it is more important to distinguish situation 1 (no measurement at all) from the others and to do that, one can look at the value of area under the dose-response curve (AUC). AUC has been calculated for all measurements, regardless of the curve fitting, experimental noise and resistance. Therefore, if AUC=NaN, it means no measurement at all (situation 1). Otherwise, GI50 of NaN corresponds to one of the situations 2-4.

Date Updated:
2016-08-24

Date Retrieved from Center:
11/13/2015

################################################################
Metadata Information
################################################################

Metadata information regarding the entities used in the experiments is included in the accompanied metadata. A metadata file per entity category is included in the package. For example, the metadata for all the cell lines that were used in the dataset are included in the Cell_Lines_Metadata.txt file.
Descriptions for each metadata field can be found here: http://www.lincsproject.org/data/data-standards/
[/generic/datapointFile]
[/generic/reagents_studied]
