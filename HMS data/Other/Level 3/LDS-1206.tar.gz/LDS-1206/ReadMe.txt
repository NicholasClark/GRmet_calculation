################################################################
Dataset Information
################################################################

Dataset Name:
Sensitivity measures of MDA-MB-231 and HME-1 cell lines to LINCS Pilot Phase TransCenter Project kinase inhibitors

Dataset Description:
To generate measures of the sensitivities of two cell lines to LINCS Pilot Phase TransCenter Project kinase inhibitors we treated cells with single drugs and measured the cell number after three days of drug exposure. This dataset is experimental data. Calculated metrics (IC50, GI50, EC50, Hill coefficient and Einf; see Fallahi-Sichani et al. Nat Chem Biol (2013) 9, p.708714) from this data are available in HMS-LINCS dataset 20216.

--Files in Package:
20215.txt
Cell_Line_Metadata.txt
MetadataPropertyMapping.txt
ReadMe.txt
Small_Molecule_Metadata.txt

################################################################
Center-specific Information
################################################################

Center-specific Name:
HMS_LINCS

Center-specific Dataset ID:
20215

Center-specific Dataset Link:
http://lincs.hms.harvard.edu/db/datasets/20215/

################################################################
Assay Information
################################################################

Assay Protocol:
1. Cells were plated at 2000 cells per well in 4x 384 well plates per cell line and grown for 24 hours.<br />
2. Three plates per cell line were treated with single drugs using the HP D300 drug dispenser.<br />
3. Immediately after treatment the untreated fourth plate for each cell line was fixed and stained by adding 20 �l of fixative containing formaldehyde solution and Hoechst 33342 for a final concentration of 3% formaldehyde and 250 ng/ml Hoechst (no wash step). This plate was sealed and kept at 4C until day 3 of the assay.<br />
4. At day 3 the remaining plates were fixed, stained, and sealed as described in step 3.<br />
5. After 1 hour all plates were scanned with a PE Operetta high throughput plate scanner (10x WD lens with excitation peak at 380nm and emission peak at 445nm).<br />
6. Nuclei were counted using the Columbus software (module: 'Find Nuclei'; Method B; default parameters).<br />
7. Well cell counts for the 3 replicates on each experiment day for each compound concentration are presented.<br />
8. The cell count results were normalized by plate and the three replicates were averaged to yield the average relative cell count and the relative growth for each cell line, drug and concentration (calculations described below). Well positions for the treatments and controls were randomly assigned on the 3 replicate experimental plates. If there was a significant difference (t-test with p<0.05) between the controls on the edge and the controls in the center of the plates, all cell count values in wells on the edge were corrected by the ratio of the average of controls on the edge to the average of controls in the center.<br />
<br />
Relative cell count calculation: replicate average well cell count divided by the interquartile mean of the control cell count within the same plate</br />
<br />
Relative growth calculation: [(replicate average well cell count) - (interquartile mean of cell count for day 0 plate)] divided by [(interquartile mean of cell count for controls within the same plate) - (interquartile mean of cell count for day 0 plate)].

Date Updated:
2015-07-01

Date Retrieved from Center:
11/13/2015

################################################################
Metadata Information
################################################################

Metadata information regarding the entities used in the experiments is included in the accompanied metadata. A metadata file per entity category is included in the package. For example, the metadata for all the cell lines that were used in the dataset are included in the Cell_Lines_Metadata.txt file.
Descriptions for each metadata field can be found here: http://www.lincsproject.org/data/data-standards/
[/generic/datapointFile]
[/generic/reagents_studied]
